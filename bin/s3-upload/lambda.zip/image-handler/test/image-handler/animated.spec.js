"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const rekognition_1 = __importDefault(require("aws-sdk/clients/rekognition"));
const s3_1 = __importDefault(require("aws-sdk/clients/s3"));
const fs_1 = __importDefault(require("fs"));
const image_handler_1 = require("../../image-handler");
const lib_1 = require("../../lib");
const s3Client = new s3_1.default();
const rekognitionClient = new rekognition_1.default();
const image = fs_1.default.readFileSync("./test/image/25x15.png");
describe("animated", () => {
    it("Should create non animated image if the input image is a GIF but does not have multiple pages", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const request = {
            requestType: lib_1.RequestTypes.DEFAULT,
            contentType: lib_1.ContentTypes.GIF,
            bucket: "sample-bucket",
            key: "sample-image-001.gif",
            edits: { grayscale: true },
            originalImage: image,
        };
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // SpyOn InstantiateSharpImage
        const instantiateSpy = jest.spyOn(imageHandler, "instantiateSharpImage");
        yield imageHandler.process(request);
        expect(instantiateSpy).toHaveBeenCalledTimes(2);
        expect(instantiateSpy).toHaveBeenCalledWith(request.originalImage, request.edits, { failOnError: false, animated: false });
    }));
    it("Should create animated image if the input image is GIF and has multiple pages", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const gifImage = fs_1.default.readFileSync("./test/image/transparent-5x5-2page.gif");
        const request = {
            requestType: lib_1.RequestTypes.DEFAULT,
            contentType: lib_1.ContentTypes.GIF,
            bucket: "sample-bucket",
            key: "sample-image-001.gif",
            edits: { grayscale: true },
            originalImage: gifImage,
        };
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // SpyOn InstantiateSharpImage
        const instantiateSpy = jest.spyOn(imageHandler, "instantiateSharpImage");
        yield imageHandler.process(request);
        expect(instantiateSpy).toHaveBeenCalledTimes(1);
        expect(instantiateSpy).toHaveBeenCalledWith(request.originalImage, request.edits, { failOnError: false, animated: true });
    }));
    it("Should create non animated image if the input image is not a GIF", () => __awaiter(void 0, void 0, void 0, function* () {
        // Arrange
        const request = {
            requestType: lib_1.RequestTypes.DEFAULT,
            contentType: lib_1.ContentTypes.PNG,
            bucket: "sample-bucket",
            key: "sample-image-001.png",
            edits: { grayscale: true },
            originalImage: image,
        };
        // Act
        const imageHandler = new image_handler_1.ImageHandler(s3Client, rekognitionClient);
        // SpyOn InstantiateSharpImage
        const instantiateSpy = jest.spyOn(imageHandler, "instantiateSharpImage");
        yield imageHandler.process(request);
        expect(instantiateSpy).toHaveBeenCalledTimes(1);
        expect(instantiateSpy).toHaveBeenCalledWith(request.originalImage, request.edits, { failOnError: false, animated: false });
    }));
});
//# sourceMappingURL=animated.spec.js.map